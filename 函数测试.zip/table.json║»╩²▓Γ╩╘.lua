--json的格式可在网上查找学习

local js = '[{"t":"thjg"}]'
print("————————————————————————————\n\n")
print("JsonArray格式：\n")
print(js,"\n\n转为：\n")
print(table.json(js),"\n\n")
print("————————————————————————————\n\n")
js = '{"t":"thjg","yuff":{"fjgv":123,"tuy":355},"001": {"component": "x","determinantType": "id","determinant": "pld","header": "P","determinantValue": "null"}}'
print("JsonObject格式：\n")
print(js,"\n")
print(table.json(js),"\n\n")
print("————————————————————————————\n\n")
js = [[{
  "code": "OK",
  "message": "",
  "data": {
    "departmentId": 320000,
    "name": "江苏省",
    "children": [
      {
        "departmentId": 320200,
        "name": "无锡市",
        "children": [
          {
            "departmentId": 320211,
            "name": "滨湖区",
            "children": []
          }
        ]
      },
      {
        "departmentId": 320500,
        "name": "苏州市",
        "children": []
      }
    ]
  }
}]]
print("两种的组合格式：\n")
print(js,"\n")
print(table.json(js),"\n\n")
print("————————————————————————————\n\n")
print("参数为空时，报错内容如下：\n",table.json(),"\n\n")
print("转换出错时，报错内容如下：\n",table.json("测试"))