path = "/sdcard/测试/1"
--文件夹创建
print(file.mkdir(path),"已创建\n/sdcard/测试/1\n路径的子文件夹\n\n")

--创建文件并写入数据
io.open(path.."/HelloLuaJ.txt","w+"):write("Hello World !")
print("创建文件：\n"..path.."/HelloLuaJ.txt\n并写入：Hello World !\n\n")

--文件夹或文件最后修改时间
print(path.."该文件夹最后修改时间：\n",file.lastTime(path),"\n")
print(path.."/HelloLuaJ.txt该文件最后修改时间：\n",file.lastTime(path.."/HelloLuaJ.txt"),"\n")

--文件夹遍历
print("/sdcard/DCIM路径文件一级遍历：",file.list("/sdcard/DCIM"))

--文件夹大小
print("文件夹大小：",file.size("/sdcard/DCIM",false).."\n即：",file.size("/sdcard/DCIM"),"\n")

--判断文件存在
print("判断"..path.."/HelloLuaJ.txt文件是否存在：\n",file.exists(path.."/HelloLuaJ.txt"),"\n")--参数一文件路径 返回bool

--判断文件类型
print("判断"..path.."/HelloLuaJ.txt文件类型：\n",file.check(path.."/HelloLuaJ.txt"),"\n")--参数一文件路径 返回bool

--读取文件内容
print("读取"..path.."/HelloLuaJ.txt内容：\n",file.read(path.."/HelloLuaJ.txt"))--参数一文件路径 返回String

--下载文件
file.download("http://baidu.com/index.html","/sdcard/baidu.html")



---[path函数]------------------
local a = "/storage/emulated/0/////Notes/101_smali/catch_/me_/if_/you_/can_/ActivityMain.smali"

print(file.path(a),"\n") --/storage/emulated/0/Notes/101_smali/catch_/me_/if_/you_/can_/ActivityMain.smali 12
--传入路径,返回参数两个
--一个是正确全路径，一个是分割长度

local a = "/storage/emulated/0/Notes/101_smali/catch_/me_/if_/you_/can_/ActivityMain.smali"
print(file.path(a,0),"\n")
--两个参数时，第二个参数为截取指令，默认从1开始截取
--0  表示直接返回最末尾的文件名ActivityMain.smali
--大于0时，表示截取到第几个/之前
print(file.path(a,1),"\n") -- 
print(file.path(a,2),"\n") --/storage
print(file.path(a,5),"\n") --/storage/emulated/0/Notes

--参数小于0时，表示反向截取，与正向截取相似
print(file.path(a,-1),"\n") --/storage/emulated/0/Notes/101_smali/catch_/me_/if_/you_/can_
print(file.path(a,-2),"\n") --/storage/emulated/0/Notes/101_smali/catch_/me_/if_/you_
print(file.path(a,-5),"\n") --/storage/emulated/0/Notes/101_smali/catch_

--超出截取范围(分割长度)将报错
--print(file.path(a,80),"\n")
---[path函数]------------------



---[pathend函数]------------------
--file.pathEnd 截取路径末尾文件或文件夹名
path = "/sdcard/Notes/"
print(path,"\n","截取结果:")
print(true,file.pathEnd(path,true))
print(false,file.pathEnd(path,false))

path1 = "/sdcard/Notes"
print("\n",path1,"\n","截取结果:")
print(true,file.pathEnd(path1,true))
print(false,file.pathEnd(path1,false))

path2 = "/sdcard/Notes/yujd.txt"
print("\n",path2,"\n","截取结果:")
print(true,file.pathEnd(path2,true))
print(false,file.pathEnd(path2,false))

path3 = "/sdcard/Notes/ah_1.0.0.v.lua"
print("\n",path3,"\n","截取结果:")
print(true,file.pathEnd(path3,true))
print(false,file.pathEnd(path3,false))
---[pathend函数]------------------



---[check函数]------------------
print(file.check("/sdcard/测试")); --0
print(file.check("/sdcard/测试.txt")); --1
print(file.check("/sdcard/Android/")); --2

--返回参数为number
--0表示文件或文件路径不存在
--1表示判断路径为文件
--2表示判断路径为文件夹
---[check函数]------------------



---[zip函数]------------------
被压缩文件路径="/sdcard/test.txt"
压缩文件路径="/sdcard/test.zip"
密码="123456"
模式="zip"
print(file.zip(被压缩文件路径,压缩文件路径,密码))--第四个参数不填默认为压缩
模式="unzip"
被解压文件路径="/sdcard/test.zip"
解压后路径="/sdcard/测试/"
print(file.zip(被解压文件路径,解压后路径,密码,模式))
---[zip函数]------------------
