    --loadassets(name) --从apk内的assets文件夹中加载脚本
    --name 文件名 ，如 assets内置.lua
    --assets内的文件不需要添加id
    --返回值：加载失败返回nil，加载成功返回一个匿名function
--使用方式如loadfile一样：
loadassets("assets内置.lua")()

    --loadres("dir/id_name") 或 loadres("dir","id_name")
    --从资源文件中加载脚本
    --该函数需要添加完文件后，在arsc和dex中添加上资源id
    --dir 在res下添加脚本时的文件夹名，如drawable、layout、xml、raw
    --id_name 添加id时的id名字，如 测试、toast、内置等
    --返回值：加载失败返回nil，加载成功返回一个匿名function
--使用方式如loadfile一样：
loadres("drawable/内置")()
loadres("drawable", "内置")()

    --loadstring(code) --从字符串中加载脚本代码
    --除了不能传function，其他的同load函数。本质上只是一个函数名字兼容老版本Lua的函数
loadstring("gg.alert(1)")()

    --loadurl(url, header) --从云端链接加载脚本
    --为load(gg.makeRequest("url").content)()和loadstring(gg.makeRequest("url").content)()的简写版
    --header传递请求头，不需要时可不写
    --优点：不存在使用load函数时可搜索的情况
loadurl("https://dm.lightstar.top/file/test.lua")()