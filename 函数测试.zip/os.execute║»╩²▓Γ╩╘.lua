print(os.execute)
dirPath = "/sdcard/测试/1/2/3/4/5/"

print(os.execute("cd " .. dirPath))
print(os.execute("mkdir " .. dirPath))