local as = ""
for n=1,50000 do
  as = as.."A"..n
end
print("gsub耗时")
o=os.clock()
local a = as
a=a:gsub("2","666")
print(os.clock()-o)

print("replace耗时")
o=os.clock()
local b = as
b=b:replace("2","666")
print(os.clock()-o)

print("替换结果是否相等",b==a)