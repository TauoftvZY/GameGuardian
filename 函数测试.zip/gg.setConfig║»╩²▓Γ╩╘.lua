--新优化支持中文方式，和使用设置栏内所见复选框上数字或文字进行设置（如对游戏隐藏的设置弹窗上，见到的1 2 3 4等字样）
print(gg.setConfig("选择内存范围",32,"Xa"))
print(gg.setConfig("自动暂停游戏","是"))
print(gg.setConfig("旁路模式","没有"))
print(gg.setConfig("对游戏隐藏", 2, 3, 4))
gg.sleep(1000)

--这是旧版setConfig的写法，新版也支持
print("设置A，V内存范围\n")
print("效果与gg.setRanges(1048608)等同\n")
print(gg.setConfig(2131427457, 1048608))
print("对游戏隐藏234\n")
print(gg.setConfig(2131427463, 14))
print("设置旁路模式：冻结\n")
print(gg.setConfig(2131427464, 2))
print(gg.getConfig(2131427464))
gg.sleep(1000)