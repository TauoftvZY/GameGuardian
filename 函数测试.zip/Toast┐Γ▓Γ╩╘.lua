Gravity = luajava.bindClass("android.view.Gravity")
print(toast)

toast.setMode(1) --设置下面消息依次显示，对所有消息有效

toast.setGravity(Gravity.BOTTOM)--当不使用该函数时，默认为屏幕正中间显示
--setGravity对white、black、hint、success、warn、error无效
toast.show("开始测试")
toast.showShort("测试")
toast.showLong("测试1")
toast.crossPage("测试2")
toast.delay("延迟消息",2000)

--setGravity对white、black、hint、success、warn、error无效
--如果要使用对应的风格，且自定义显示位置，请使用diyShow
--传递对应的名字（hint、success、warn、error、提示、成功、警告、错误），调用对应布局，如toast.diyShow("hint","测试")、toast.diyShow("error","测试")
toast.white("白色")
toast.black("黑色")
toast.hint("提示")
toast.success("成功")
toast.warn("警告")
toast.error("错误")

--toast.cancel() --用于清理消息队列，一般用不上
--toast.setStyle() --设置消息样式，但不直接显示，一般用不上，因为已经有diyShow了

import "loadlayout"
import "android.widget.TextView"
import "android.widget.Button"
import "android.widget.LinearLayout"
import "android.view.LayoutInflater"

local a = {
  LinearLayout;
  layout_height="fill";
  orientation="vertical";
  layout_width="fill";
  gravity="center";
  {
    TextView; --布局必须有一个TextView
    layout_height="18%w";
    background="#FFAAAAFF";
    Id = 0x0102000b; --TextView必写内容，注意Id两个字母的大小写
    layout_marginTop="30dp";
    layout_width="40%w";
    layout_gravity="center";
    gravity="center";
  };
  {
    Button;
    layout_height="18%w";
    text="这里是演示用的其他布局";
  }
}

local vwe = loadlayout(a)

toast.setGravity() --切换为居中显示
toast.diyShow(vwe,"这里是测试",false)
 --如果第三个参数设置true，即为全局生效，下次执行脚本时toast.show、toast.showShort、toast.showLong的布局就是自定义布局

toast.setGravity(Gravity.BOTTOM)
toast.diyShow("hint", "hint布局显示")