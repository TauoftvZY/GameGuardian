--[[
		file.check(path or File) --判断该文件路径或者java的File对象 是文件还是文件夹
			--参数1：可以传string类型的文件路径，或者时由usedata类型的File对象
			--返回值：0表示文件或文件夹不存在，1表示为文件，2表示为文件夹
				 
		file.chmod(path or File, wrx) --更改文件读、写、执行权限
			--参数1：可传文件路径或者文件对象
			--参数2：可传权限八进制语法，不传时默认777
			--返回值：文件不存在则返回nil，文件存在则返回命令执行情况

		file.copy(path1 or File1, path2 or File2) --从路径1拷贝文件到路径2，当路径2的父目录不存在时会创建父目录
			--仅能拷贝文件，不能拷贝文件夹
			--path1 和 path2必须为全路径
			--当path2有文件存在时，拷贝过去的文件将以 时间戳 + .copy作为文件后缀
			--返回值：失败false，成功返回拷贝后文件的路径

		file.create(path or File) --创建文件或文件夹
			--参数1：可传文件路径或者文件对象
			--返回值：文件存在时返回true
				文件不存在，若路径以/结尾，则进行文件夹创建，且父文件夹不存在时会创建父文件夹，创建成功返回true，失败返回false
				文件不存在，若没有以/结尾，则先将父文件夹创建，之后会创建一个该名字的空文件，创建成功返回true，失败返回false

		file.download(url , path or File, header or nil) --下载url链接内容到本地
			--参数1：链接
			--参数2：下载内容需要存放到的路径或文件对象，当文件路径不存在时会创建
			--参数3：可填也可不填，用于传请求头，一般直链不需要

		file.exists(path or File) --文件或文件夹是否存在
			--参数1：文件
			--返回值：存在true，不存在false

		file.isdir(path or File) --是不是文件夹
			--参数1：文件路径或者File对象
			--返回值：是true 不是false

		file.isfile(path or File) --是不是文件
			--参数1：文件
			--返回值：是true，不是false

		file.lastTime(path or File) --文件最后修改日期
			--参数1：文件或对象
			--返回值：这种格式的日期 2024-07-20 14:22:53

		file.mkdirs(path or File) --多级文件夹创建
			--参数1: 文件夹
			--返回值：成功true，失败false

		file.name(path or File) --获取文件名
			--返回值：文件夹返回文件夹名，文件则返回带文件拓展名的名字
				如/DM/dm.txt 返回dm.txt

		file.parent(path or File) --获取文件的父路径
			--返回值：如/DM/dm.txt 返回 /DM

		file.read(path or File) --读取文件的全部内容
			--返回值：文件存在，返回内容；文件不存在返回false

		file.rename(path1 or File1, path2 or File2) --文件重命名或移动
			--参数1和参数2均需要填写完整路径或者文件File对象
			--返回值：true or false

		file.size(path or File) --文件或者文件夹大小
			--返回值：转换为具有单位的文件大小

		file.split(path or File, num) --文件分割成多份
			--参数1：文件
			--参数2：份数
			--当份数小于1时不执行分割文件，且返回true
			--当份数大于文件以k作为单位时的大小时（即分割后的每个文件最低大小为1k)，返回false
			--文件不存在或者不是文件时返回false
			--分割出的文件以 [第几份].拓展名 作为文件后缀
			--返回值：成功则返回分割文件的目录表

		file.sub(path or File, start_index, end_index) --文件路径截取
			--以 /sdcard/Notes/apks/xxx.txt 为例
			--第一个/之前是 index=1，sdcard 是 index=2，后面依次类推
			--当只传start_index，不传end_index时，就是取第index个位置的文件夹名或文件名，如3取的是Notes
			--当start_index和end_index都传入时，将截取这两个位置之间的路径，如1,4 截取返回/sdcard/Notes/apks

		file.suf(path or File) --文件拓展名截取，当文件没有拓展名时返回为空

		file.write(path or File, string) --向文件写入内容
			--参数1：路径或文件对象
			--参数2：要写入的字符串（默认UTF-8格式，不可更改）

		file.list(path or File, type, regex) --按规则遍历文件
			--参数1：路径
			--参数2：模式
				file.TYPE_NAME_ENDS 匹配文件名结尾
				file.TYPE_NAME_STARTS 匹配文件名开头
				file.TYPE_PATH_ENDS 匹配路径结尾
				file.TYPE_PATH_STARTS 匹配路径开头
				file.TYPE_REGEX 纯正则表达式匹配，不区分是文件名还是路径的开头或者结尾
				file.TYPE_DIR 匹配文件夹
				file.TYPE_FILE 匹配文件
				file.TYPE_ALL 遍历所有文件夹或者文件
				file.TYPE_CHILD 按遍历深度筛选文件

				该参数不传递时，默认TYPE_ALL
			--参数3：正则表达式，语法遵循java中的正则表达式
				--当参数2传递file.TYPE_CHILD时，参数3可传遍历深度
				--当参数2传递file.TYPE_CHILD，且参数3传递正则表达式时，在参数4传递遍历深度

				--正则表达式可不传递，不传递时默认满足模式下的所有路径
				--遍历深度可不传递，不传递时默认深度1，即当前文件夹的一级子文件
			--返回值：以表的形式返回遍历结果

			用法：遍历apks文件夹下lua文件 
				file.list("/sdcard/MT2/apks/", file.TYPE_NAME_ENDS, "lua")
				遍历apks文件夹下xxx名字开头的文件 
				file.list("/sdcard/MT2/apks/", file.TYPE_NAME_STARTS, "xxx")
				遍历以/sdcard/MT2/apks/开始的路径 
				file.list("/sdcard/MT2", file.TYPE_PATH_STARTS, "/sdcard/MT2/apks/")
				遍历以 .txt.xxx.lua结尾的文件
				file.list("/sdcard/", file.TYPE_PATH_ENDS, ".txt.xxx.lua")
				遍历所有文件夹
				file.list("/sdcard/", file.TYPE_DIR)
				遍历所有文件
				file.list("/sdcard/", file.TYPE_FILE)
				遍历所有文件夹和文件
				file.list("/sdcard", file.TYPE_ALL)或者file.list("/sdcard/")
				遍历/sdcard/下子目录，优点是想遍历多少级的文件夹就遍历多少级的
				file.list("/sdcard/", file.TYPE_CHILD) --一级
				file.list("/sdcard/", file.TYPE_CHILD, 1) --一级
				file.list("/sdcard/", file.TYPE_CHILD, 4) --一到四级
				正则遍历，遍历路径里含有数字的
				print(file.list("/sdcard/MT2", file.TYPE_REGEX, "/sdcard/MT2/[0-9_/]*")) 
				--该用法需要对java的正则表达式熟悉


		file.delete(path or File, type, regex) --按规则遍历后删除对应文件
			--用法同file.list，只不过这个是删除
			--返回值：以表的形式返回被删除的文件

	['file'] = {
		['TYPE_ALL'] = 128,
		['TYPE_CHILD'] = 256,
		['TYPE_DIR'] = 32,
		['TYPE_FILE'] = 64,
		['TYPE_NAME_ENDS'] = 1,
		['TYPE_NAME_STARTS'] = 4,
		['TYPE_PATH_ENDS'] = 2,
		['TYPE_PATH_STARTS'] = 8,
		['TYPE_REGEX'] = 16,
		['check'] = file.check,
		['chmod'] = file.chmod,
		['copy'] = file.copy,
		['create'] = file.create,
		['delete'] = file.delete,
		['download'] = file.download,
		['exists'] = file.exists,
		['isdir'] = file.isdir,
		['isfile'] = file.isfile,
		['lastTime'] = file.lastTime,
		['list'] = file.list,
		['mkdirs'] = file.mkdirs,
		['name'] = file.name,
		['parent'] = file.parent,
		['read'] = file.read,
		['rename'] = file.rename,
		['size'] = file.size,
		['split'] = file.split,
		['sub'] = file.sub,
		['suf'] = file.fileSuffix,
		['write'] = file.write,
	},
]]--



local path = "/storage/emulated/0/MT2/apks/"

print("路径：", path)
print("文件是否存在：", file.exists(path))
print("是否是文件：", file.isfile(path))
print("是否是文件夹：", file.isdir(path))
print("文件类型/状态：", file.check(path))
print("父路径：", file.parent(path))
print("文件名：", file.name(path))
print("大小：", file.size(path))
print("文件最后修改时间：", file.lastTime(path))
print("修改读写执行权限777：", file.chmod(path, 777))
print("遍历当前目录：", file.list(path))
print("-------------------------\n")
local child_dir = path.."/and/and/and/and/and/and/and/and/"
local child = child_dir.."dm.lua"
print("子文件夹路径：", child_dir)
print("子文件路径：", child)
print("创建多级文件夹：", file.mkdirs(child_dir))
print("创建子文件：", file.create(child))
print("子文件的拓展名：", file.suf(child))
print("任意截取路径1~4", file.sub(child, 1, 4))
print("写入内容：", file.write(child, "3147359496"))
print("读取内容：", file.read(child))
local copy = file.copy(gg.getFile(), child)
print("拷贝当前测试脚本内容到刚创建的and文件夹中：", copy)
copy = child_dir.."base64.lua"
print("下载云端文件到该目录：", file.download("http://baidu.com/index.html", copy))
print("将"..copy.."文件分割成两份：", file.split(copy, 2))
print("删除该目录下的所有文件：", file.delete("/storage/emulated/0/MT2/apks/and",file.TYPE_ALL))
--print("文件重命名", file.rename("/sdcard/Notes", "/sdcard/test"))



---[zip函数]------------------
被压缩文件路径="/sdcard/test.txt"
压缩文件路径="/sdcard/test.zip"
密码="123456"
模式="zip"
print(file.zip(被压缩文件路径,压缩文件路径,密码))--第四个参数不填默认为压缩
模式="unzip"
被解压文件路径="/sdcard/test.zip"
解压后路径="/sdcard/测试/"
print(file.zip(被解压文件路径,解压后路径,密码,模式))
---[zip函数]------------------
