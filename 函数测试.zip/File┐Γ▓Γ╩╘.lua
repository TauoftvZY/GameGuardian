local path = "/storage/emulated/0/MT2/apks/"

print("路径：", path)
print("文件是否存在：", file.exists(path))
print("是否是文件：", file.isfile(path))
print("是否是文件夹：", file.isdir(path))
print("文件类型/状态：", file.check(path))
print("父路径：", file.parent(path))
print("文件名：", file.name(path))
print("大小：", file.size(path))
print("文件最后修改时间：", file.lastTime(path))
print("修改读写执行权限777：", file.chmod(path, 777))
print("遍历当前目录：", file.list(path))
print("-------------------------\n")
local child_dir = path.."/and/and/and/and/and/and/and/and/"
local child = child_dir.."dm.lua"
print("子文件夹路径：", child_dir)
print("子文件路径：", child)
print("创建多级文件夹：", file.mkdirs(child_dir))
print("创建子文件：", file.create(child))
print("子文件的拓展名：", file.suf(child))
print("任意截取路径1~4", file.sub(child, 1, 4))
print("写入内容：", file.write(child, "3147359496"))
print("读取内容：", file.read(child))
local copy = file.copy(gg.getFile(), child)
print("拷贝当前测试脚本内容到刚创建的and文件夹中：", copy)
copy = child_dir.."base64.lua"
print("下载云端文件到该目录：", file.download("http://baidu.com/index.html", copy))
print("将"..copy.."文件分割成两份：", file.split(copy, 2))
print("删除该目录下的所有文件：", file.delete("/storage/emulated/0/MT2/apks/and",file.TYPE_ALL))
--print("文件重命名", file.rename("/sdcard/Notes", "/sdcard/test"))



---[zip函数]------------------
被压缩文件路径="/sdcard/test.txt"
压缩文件路径="/sdcard/test.zip"
密码="123456"
模式="zip"
print(file.zip(被压缩文件路径,压缩文件路径,密码))--第四个参数不填默认为压缩
模式="unzip"
被解压文件路径="/sdcard/test.zip"
解压后路径="/sdcard/测试/"
print(file.zip(被解压文件路径,解压后路径,密码,模式))
---[zip函数]------------------
