--[[可以传匹配串过滤internalName（原版getRangesList)，
也可以传long型地址过滤start和end，
也可以传表{internalName="",address=0,name="",state="",type=""}格式来多个条件过滤，且internalName等均支持正则匹配]]

--无参数获取全部内存列表
print(gg.getRangesListX())

--传字符串过滤internalName
print(gg.getRangesListX('^/data/*lib*.so$'))

--传地址过滤，得地址所在范围
print(gg.getRangesListX(0xBBBCA6BC))

--多个参数过滤 address，internalName，end，start，type，state等均可作为过滤条件
print(gg.getRangesListX({
    internalName = '^/data/*lib*.so$',
    state = 'Ca',
    type = 'rw'
}))