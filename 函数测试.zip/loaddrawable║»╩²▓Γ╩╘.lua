--支持加载xml编写的drawable可绘制资源，如vector、shape、layer-list、state-list等等
--支持加载的是xml源码或者已编译的xml

--用法一：直接传xml文本
p=[[
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
	android:tint="#FFFFFFFF"
	android:height="24dp"
	android:width="24dp"
	android:viewportWidth="24.0"
	android:viewportHeight="24.0">
	<path
		android:fillColor="#FF000000"
		android:pathData="M11,17h2v-6h-2v6zM12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8zM11,9h2L13,7h-2v2z" />
</vector>
]]
print(loaddrawable(p))

--用法二：直接传路径
print(loaddrawable("/sdcard/xxxx.xml"))

--用法三：传直链
print(loaddrawable("http://127.0.0.1:5555/test"))

--用法四：当xml资源与当前脚本处于同一目录时
print(loaddrawable("x")) --省略路径，可以只写文件名

--用法五：在ImageView中的使用
src="x.xml"; --全路径或者带拓展名的文件名
src="http://127.0.0.1:5555/x.xml" --以.xml结尾的直链
--直接传文本
src=[[
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
	android:tint="#FFFFFFFF"
	android:height="24dp"
	android:width="24dp"
	android:viewportWidth="24.0"
	android:viewportHeight="24.0">
	<path
		android:fillColor="#FF000000"
		android:pathData="M11,17h2v-6h-2v6zM12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8zM11,9h2L13,7h-2v2z" />
</vector>
]]

--方法六：任意支持background属性的布局
同asrc的