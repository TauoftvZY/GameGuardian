print(gg.isVPN())
