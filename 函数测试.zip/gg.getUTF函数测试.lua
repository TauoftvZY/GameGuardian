--gg.getUTF(mode, addressItems|selected) 获取连续地址中的字符串表达式
--共两个参数
--参数mode : 对应GG中的“以联合搜索复制”功能选项，这里直接输入字符串即可
--如             UTF-8  UTF-16LE HEX HEX+UTF-8 HEX+UTF-16LE HEX+UTF-8+UTF-16LE

--参数addressItems ：不传值时默认情况下是搜索列表
--                    可传地址列表如getResults、getListItems、getValues、getSelectedElements、getSelectedListItems、getSelectedResults等函数所获取的地址列表
--                    也可以是自己构建的结构同{[index]={address=0x0,value=1,flags=4},}的地址列表，其中address、value、flags三个值必须存在

--参数selected ：与addressItems共用相同参数位，当第二个参数位置传递为整数number时，切换为selected，用于Tab的选择
--                selected为1时，表示从搜索列表获取选中项；为2时，表示从保存列表获取选中项；为3时，表示从内存编辑页面获取选中项

--第二个参数不传table、number类型值时（即nil），默认从搜索列表获取选中项

print(gg.getUTF("UTF-16LE"))
print(gg.getUTF("UTF-8",2))
print(gg.getUTF("HEX",2))
--print(gg.getUTF("HEX+UTF-8",gg.getResults(10)))