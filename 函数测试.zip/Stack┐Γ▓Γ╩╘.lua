stack.clearAll()
stack.newGlobalsStack()
stack.setGlobals("主脚本",_G)

P = ""

function A(n, m)
    for j=n,m do
       P = P.."\n输出："..j
    end
end

stack.run("stack.getValue('主脚本','A')(5,10)\n print(stack.getValue('主脚本','P'))","测试1")
stack.run("stack.getValue('主脚本','A')(100,1000)\n print(stack.getValue('主脚本','P'))","测试2")
stack.run("stack.getValue('主脚本','A')(1001,1500)\n print(stack.getValue('主脚本','P'))","测试3")
--print(P)
--print(stack.Tostring())


