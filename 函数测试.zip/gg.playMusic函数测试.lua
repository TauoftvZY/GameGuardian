function Main0()
SN = gg.choice({
	 "播放",
	 "暂停",
}, nil, "")
if SN==1 then
	 HS1()
end
if SN==2 then
	 HS2()
end
FX=0
end

function HS1()
gg.playMusic("http://music.163.com/song/media/outer/url?id=518686034.mp3")
end

function HS2()
gg.playMusic("stop")
end


Main0()