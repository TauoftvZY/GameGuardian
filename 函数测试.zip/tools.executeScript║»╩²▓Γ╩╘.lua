path = "/storage/emulated/0/print.lua"
dir = "/storage/emulated/0/MT2/apks/"

tools.executeScript(path, 0, dir, true)

--第一个参数，脚本路径
--第二个参数，运行模式
   --0 正常运行脚本，无其他操作
   --1 输出 .lasm文件（反编译）
   --2 输出 .load.tar文件（转储所有代码加载）
   --4 输出 .log.txt文件（记录大多数脚本调用）

   -- 多个模式时用 | 运算符 如要输出.lasm和.log.txt 是 1|4

--第三个参数，当采用非0模式时的.xxxx文件输出路径
--第四个参数，是否在调用tools.executeScript另外一个脚本后中断本脚本
   --true 不中断
   --false 中断  第四参数未传入时为默认false
   
   