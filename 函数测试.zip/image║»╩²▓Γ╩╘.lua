gg.toast("开始测试")
--加载蓝奏云文件图片
local header = {}
header["Accept-Language"]="zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7"
header["Cookie"]="UM_distinctid=1747043cd08217-0d948f1d4d5f25-527a460b-43ad0-1747043cd0abf; CNZZDATA1258381272=818363134-1599609873-https%253A%252F%252Fm.baidu.com%252F%7C1599609873; down_ip=1; CNZZDATA1253610887=1315526113-1606037814-https%253A%252F%252Fm.baidu.com%252F%7C1606037814"
header["User-Agent"]="Dalvik/2.1.0 (Linux; U; Android 10; JNY-AL10 Build/HUAWEIJNY-AL10)"
header["Host"]="vip.d0.baidupan.com"
header["Connection"]="Keep-Alive"
header["Accept-Encoding"]="gzip"
--蓝奏云网盘图片链接
local url = "https://dumaowpj.lanzous.com/is6dKlvg04h"  --蓝奏云短链接


url = url:gsub("com/","com/tp/")
gg.toast("已加载网盘图片")
--image("https://vip.d0.baidupan.com/file/"..gg.makeRequest(url).content:match("domianload [+]+ '?(.-)'"),header,"图片加载失败")
--第一个参数为url，第二个参数为请求体，第三个参数为显示文字
--gg.sleep(200)
gg.toast("加载网盘图片方法二")
--如果前一种方法加载失败（加载失败时显示为GG修改器图标），采用该方法
--image(gg.makeRequest("https://vip.d0.baidupan.com/file/"..gg.makeRequest(url).content:match("domianload [+]+ '?(.-)'"),header).headers.Location,nil,"MOD By DM\nQQ：3147359496")

--加载有直链的网络图片,不传入请求体和文字(当然你也可以传入需要显示的文字)
--image("https://feeds-drcn.dbankcdn.com/web/1051069525419073/image/3aa0084047b420280dd148cf70eed7c5966692ee_w1479_h714")
--如果加载失败则转为加载悬浮窗图标
--image("")

--加载本地图片
--image("/storage/emulated/0/Pictures/1609835822212.png")--这里填入文件路径

--接下来我们试试长图
image("/storage/emulated/0/tencent/QQ_Images/1614076669543.jpeg")
--弹窗布局采用ScrollView，可预览长图