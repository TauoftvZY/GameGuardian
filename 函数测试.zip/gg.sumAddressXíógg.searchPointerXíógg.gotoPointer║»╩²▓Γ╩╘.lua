
--地址偏移函数
gg.sumAddressX = function(_address_table, _index, _offest, _flags)
  local _table = {
    {
      address = _address_table[_index].address + _offest,
      flags = _flags
    }
  }
  return gg.getValues(_table)
end

--_address_table 地址表             table
--地址表格式{{address=0x123},{address=0x222}}，比如gg.getResults(12)获取并返回的内容就符合参数要求
--_index地址表中的第几个地址       十进制number
--_offest该地址要偏移多少           十进制number
--_flags你要获取的数据类型          十进制number或gg.TYPE_*


--指针搜索函数
gg.searchPointerX = function(_address_table, _index, _offest, _ranges)
  gg.setRanges(_ranges)
  gg.clearResults()
  gg.searchNumber(_address_table[_index].address + _offest,4)
  local results = gg.getResults(gg.getResultsCount())
  return results
end

--_ranes为搜索的地址范围，比如只搜A中的满足要求的指针
--_offest指针偏移量，设置为0时表示该地址的指针，设置为其他值时表示该地址先偏移再指针
--当然也可用类似于gg.searchNumber(_address_table[_index].address ~ _address_table[_index].address + _offest,4)的来进行指针偏移范围内搜索
--指针默认返回为表，值类型为Dword

--指针跳转函数
gg.gotoPointer = function(_address_table, _index, _offest, _flags)
  gg.clearResults()
  local addr = {{address=(_address_table[_index].value + _offest)&0xFFFFFFFF,flags = _flags}}
  return gg.getValues(addr)
end

--_offest起到先转到指针再偏移，若设置为0则为直接跳转指针


---------—————————————————

gg.clearResults()
gg.setRanges(-2080896) --内存O
gg.searchAddress("E0000004",-1,4) --搜索数据，你可以搜索地址searchAddress或者数值searchNumber
print("搜索地址E0000004\n")
local rs = gg.getResults(gg.getResultsCount())
local sum = gg.sumAddressX(rs,1,-4,4)--偏移-4
print("偏移-4结果：\n",sum)

local UpPointer = gg.searchPointerX(sum,1,0,2) --设置指针偏移0，内存范围Jh
print("地址指针搜索结果：\n",UpPointer)

local NextPointer = gg.gotoPointer(UpPointer,8,4,4) --第8个，偏移4，获取Dword类型
print("指针跳转结果：\n",NextPointer)


print(gg.searchPointerX)
print("用法参考GG的官方API\n\n")
gg.clearResults()
gg.searchNumber(12,4)
gg.getResults(1000)
print(gg.searchPointerX(20))