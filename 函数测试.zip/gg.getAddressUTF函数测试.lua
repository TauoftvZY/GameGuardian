--gg.getAddress(start, length, mode) 获取连续地址中的字符串表达式
--共三个参数
--参数start ：开始地址值，写十进制格式或者0x十六进制格式
--参数length ：地址条数（长度），这里以每+4为一条（即Dword值时看到的条数，如内存编辑页面中显示2048条）
--参数mode : 对应GG中的“以联合搜索复制”功能选项，这里直接输入字符串即可
--如             UTF-8  UTF-16LE HEX HEX+UTF-8 HEX+UTF-16LE HEX+UTF-8+UTF-16LE
--不传递时默认UTF-8

print(gg.getAddressUTF(0xBA341DC0, 5))
print(gg.getAddressUTF(0xBA341DC0, 2048, "UTF-16LE"))
