tabletest = {[{}]=3,a=1,b=2,nil,3,5,7}
print(table.getn(tabletest))