local t = {"ushd",1,3,8,5,4,23345,1,2,3,2,2,3,2,2,2,2,2,2,2,3,{1,2,3},{"tyyy","uggh"},{1,2,3}}

table.removeRepetition(t)
print(t)