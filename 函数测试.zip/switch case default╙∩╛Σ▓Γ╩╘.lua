
--continue关键字
print("======continue关键字=======")
for n=1,20 do
   if n==15 then
     continue --跳过n==15时的循环
   end
   print(n)
end
--输出结果中，1-20，少了15


--switch case的使用

--使用()表示表达式是一个整体，使用:表示一个分支，使用{}表示一个代码块
--switch(表达式) 和 case 表达式   
--支持有值表达式，比如具体的1234，"RE"等常量值，支持变量名如下面代码所示，当使用变量名作为表达式时，变量名后面不要跟随使用:符号

--写法一
--switch(XX){ XXX }
print("======switch case写法一测试=======")
local a = 666
switch(a){ --() 可省略，{} 若省略则需要用end代替}作为switch语句结束标志
  case true:{ -- :可省略，{}成对省略或出现。不可用end代替}表示case 分支的结束，要省略{则连}一起省略
              -- {}的作用表示一个代码块，同时当被执行的case 分支有使用{}时，当a匹配某一case成功后，default语句若存在则被默认执行，若省略case 分支的{}，当a匹配成功后，default分支不会被执行
    print("true")
	--switch原有的break跳出分支不支持，这里默认分支结束，不会顺序执行case 666分支，这点与其他语言不同
  }  
  case 666 --多个case 分支合并时，前面的case分支后的表达式不得跟随:符号，只最后一个case 分支可跟随可省略:
  case 888
  case "ok":{ -- a为666,该分支将会被执行，并输出ok1
    print("ok1")
  }
  default:{ -- :和{}可省略。由于前面被执行的case分支用{}包裹，default默认被执行。default分支不是必须写的，按需要写
    print("default")
  }
  --default一定写在case 之后，不得写在case前面，这点与其他语言不同
}
--等同于
--[[
  local a = 666
  local flags = false
  if a==true then
     print("true")
  elseif a==666 or a==888 or a=="ok" then
     print("ok1")
	 flags = true
  end
  
  if flags then
    print("default")
  end
]]

--输出 ok1 default

--写法二
--switch(XX)
--  XXX
--end
print("======switch case写法二测试=======")
local a = 666
switch a --这里也可以是switch(a)，其中:和{}省略不写
  case true --其中:和{}省略不写
    print("true")
  case 666,888,"ok" --多分支合并，只写一个case，后面表达式用,分隔。其中:和{}省略不写
    print("ok2")
	--[[--同类写法
	   case 666,888,"ok":{
	     print("ok2")
	   }
	   ---------
	   case 666
	   case 888
	   case "ok":
	   print("ok")
	   ------------
	]]
  default --:和{}省略不写，当前面的case 分支被执行，且不被{}包裹时，default不被随即执行
    print("default")
end

--等同于
--[[
  local a = 666
  if a==true then
     print("true")
  elseif a==666 or a==888 or a=="ok" then
     print("ok2")
  else
    print("default")
  end
]]

--输出 ok2

--写法三
print("======switch case写法三测试=======")
local a = 666
switch(a)
  case true
    print("true")
  case 666,888,"ok" {
    print("ok2")
  }
  default
    print("default")
end
--输出结果同写法一

--写法四
print("======switch case写法四测试=======")
local a = 666
switch(a){
  case true:{
    print("true")
  }  
  case 666
  case 888
  case "ok":{
    print("ok1")
  }
  --当不需要执行其他代码或者处理case匹配失败时，default省略不写
}

--写法五
--循环中使用switch
--[[--continue关键字

for n=1,20 do
   if n==15 then
     continue --跳过n==15时的循环
   end
   print(n)
end
--输出结果中，1-20，少了15]]
print("======循环语句套switch case测试=======")
for n=1,20 do
  switch(n)
     case 1
     case 2
	  print("case", n)
	 case 15
	   continue --跳过for循环的n==15
	 case 18:{
       break --跳出for循环
	 }
	 default
	   print("default",n)
  end
end
--continue 和 break不能单独使用在switch case语句中