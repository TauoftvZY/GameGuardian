local a = "123;2488;283"

print(a:split(";"))
print(string.split(a,";"))

--这两种方法使用效果一样