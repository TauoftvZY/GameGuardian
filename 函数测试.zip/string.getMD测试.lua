--string.getMD(string, type, command)  MD即MessageDigest
--三个参数分别是
--string待计算字符串
--type编码格式
--command算法名
--当对文件计算时使用string.getMD(string, command)
--一旦你对文件计算时传为了三个参数，将调用为字符串的计算
--string文件路径

local str = "测试fhii68422"
local type = "UTF-8"

print("------------编码格式"..type.."------------")
local md5 = string.getMD(str,type,"MD5")
print("------------MD5计算结果------------")
print(md5,"\n")
local sha = string.getMD(str,type,"SHA")
print("------------SHA计算结果------------")
print(sha,"\n")
local sha1 = string.getMD(str,type,"SHA1")
print("------------SHA1计算结果------------")
print(sha1,"\n")
local sha256 = string.getMD(str,type,"SHA256")
print("------------SHA256计算结果------------")
print(sha256,"\n")
local sha384 = string.getMD(str,type,"SHA384")
print("------------SHA384计算结果------------")
print(sha384,"\n")
local sha512 = string.getMD(str,type,"SHA512")
print("------------SHA512计算结果------------")
print(sha512,"\n")

local type = "UTF-16LE"

print("------------编码格式"..type.."------------")
local md5 = string.getMD(str,type,"MD5")
print("------------MD5计算结果------------")
print(md5,"\n")
local sha = string.getMD(str,type,"SHA")
print("------------SHA计算结果------------")
print(sha,"\n")
local sha1 = string.getMD(str,type,"SHA1")
print("------------SHA1计算结果------------")
print(sha1,"\n")
local sha256 = string.getMD(str,type,"SHA256")
print("------------SHA256计算结果------------")
print(sha256,"\n")
local sha384 = string.getMD(str,type,"SHA384")
print("------------SHA384计算结果------------")
print(sha384,"\n")
local sha512 = string.getMD(str,type,"SHA512")
print("------------SHA512计算结果------------")
print(sha512,"\n\n")

print("-----------------文件相关计算-----------------")
local path = "/sdcard/test.lua"
print("------------编码格式"..type.."------------")
local md5 = string.getMD(path,"MD5")
print("------------MD5计算结果------------")
print(md5,"\n")
local sha = string.getMD(path,"SHA")
print("------------SHA计算结果------------")
print(sha,"\n")
local sha1 = string.getMD(path,"SHA1")
print("------------SHA1计算结果------------")
print(sha1,"\n")
local sha256 = string.getMD(path,"SHA256")
print("------------SHA256计算结果------------")
print(sha256,"\n")
local sha384 = string.getMD(path,"SHA384")
print("------------SHA384计算结果------------")
print(sha384,"\n")
local sha512 = string.getMD(path,"SHA512")
print("------------SHA512计算结果------------")
print(sha512,"\n")