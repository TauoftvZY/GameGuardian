--计算结果为小数

local str1 = "GG养佬院"
local str2 = "养老院"

--用法一
class = luajava.bindClass
print("——————方法一——————")
print(class("luaj.lib.StringLib$similarity"):levenshtein(str1,str2))

--用法二
print("——————方法二——————")
local dm = string.similarity(str1,str2)
print(dm,"\n")
print("即百分制相似度：\n")
print((dm*100).."%")