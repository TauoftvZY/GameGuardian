--[[
table.hasK(t, k, k1, k2, k3, ...)函数  
   判断表t内是否存在以k为键的元素（后面可传入多个k)
   没有找到结果时返回false，找到则返回true（传入多个k时，返回一个boolean值表）

table.hasV(t, v, v1, v2, v3, ...)函数  
   判断表t内是否存在以v为值的元素（后面可传入多个v)
   没有找到结果时返回false，找到则返回true（传入多个v时，返回一个boolean值表）

table.swapKV(t)函数
   将表t内的键和值交换（key<=>value），原来的键作为值，原来的值作为新值的键，得到一个新表

table.vgetK(t, v)函数
   根据值v，从表t中查找值为v的所有元素，并返回这些元素所对应的键。
   注意参数中只能传入一个表和一个值，不能传入多个值
]]


local t = {
  "a",
  "b",
  "c",
  "c",
  "b",
  u=233,
  m=666,
}

print(table.hasK(t, 2)) --判断有没有key为2的元素
print(table.hasK(t, 2, "u", "j")) --判断有没有key为2或u或m的元素
local r1, r2 = table.hasK(t, 2, "u", "p") --只获取前两个查询结果用赋值即可
print(r1, r2) --没有找到结果时返回false，找到则返回true

print(table.hasV(t, "a")) --判断是否存在value为"a"的元素
print(table.hasV(t, "a","c","j")) --多个value判断
--没有找到结果时返回false，找到则返回true

--交换table的key和value
print(table.swapKV(t)) 
--当value有重复时，由于table的key唯一，相同value中将会只保留最后一个对应的key作为新value

print(table.swapKV({
  a=1,
  b=2,
  c=3
}))

--通过value获取对应key
print(table.vgetK(t, "a")) --value不重复时返回一个key
print(table.vgetK(t, "c")) --value重复时返回多个key
--没有找到结果时返回nil