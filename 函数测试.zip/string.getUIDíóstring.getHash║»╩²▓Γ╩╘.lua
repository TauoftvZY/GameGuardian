print(string.getUID())

print(string.getHash("Hello World !"))