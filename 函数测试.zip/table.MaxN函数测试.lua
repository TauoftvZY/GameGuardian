local numtable ={1,1,2,223,4,5,6,7,8,2,3,4,5,2,9,10,34,5,6,}

function MaxN(numtable)
local value = numtable [1]
local key = 1
    for n=1,#numtable do
        if numtable[n] >=value then
            value = numtable[n]
            key = n
        end
    end
    return value,key
end

print("最大值:"..table.MaxN(numtable).M)
print("最大值的位置:"..table.MaxN(numtable).N)

print("原table排序:",numtable)