local dm={
"透视",
"穿墙",
"自杀",
"上色",
"上墙",
"爬树",
"除草",
"遁地",
"飞天"
}

function dm1(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm2(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm3(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm4(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm5(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm6(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm7(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm8(...)
n=...
print("你选择了第"..n.."个的功能")
end

function dm9(...)
n=...
print("你选择了第"..n.."个的功能")
end

u=gg.searchChoice(dm,"test")
--当功能较多时，可以使用本函数
--这样只需要在输入框内搜索关键字或词
--就可以免去翻看功能菜单的操作

--gg.searchChoice()返回的结果为dm表中是否被选中的boolean表
for n=1,#dm do  --这里用#dm或者#u都可以
  if u[n] then
    _G["dm"..n](n)
  end
end



--多级菜单检索
local item = {}
for n=1,5 do
    item[n]="➡️功能"..n
end

for n=1,5 do
    local a={}
    for j=1,10 do
        a[j]="🔸子功能"..j
    end
    for j=1,5 do
        a["⤵️次次级菜单"..j]={"1"..math.random(1,10),"2"..math.random(1,10),"3"..math.random(1,10),"4"..math.random(1,10)}
    end
    item["⏬子菜单"..n] = a
end

local a = gg.searchChoice(item,"筛选1")
print(a)