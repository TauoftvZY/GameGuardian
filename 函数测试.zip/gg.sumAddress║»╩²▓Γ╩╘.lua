local address = 0x12C801A0
local offset = 0x4

local A = gg.sumAddress(address,offset,true,4)
--四个参数
--第一参数为十进制的地址值
--第二个参数为十进制的偏移值
--第三个参数为你是否将偏移结果保存到保存列表
--第四个参数为保存类型


--直接打印
print("偏移结果表：\n",A)
---按照偏移计算器格式打印
print("\n结果："..A.address.."\n"..A.h..A.r..A.S..A.J..A.D..A.F..A.E..A.W..A.B..A.Q..A.X)