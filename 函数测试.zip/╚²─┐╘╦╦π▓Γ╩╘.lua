
--   exp1 ? exp2 @ exp3
--   原本应该是
--   exp1 ? exp2 : exp3
--   但:已经作为function的调用格式了，所以以@代替:
--   如 file:read str:sub等格式的函数调用占用
--   所以用 ? @代替
--   书写格式为 exp1 ? exp2 @ exp3
--   运算时从左至右
--   当exp1为真时，跳到exp2并返回exp2的值，而exp3不会被执行
--   当exp1为假时，跳到exp3并返回exp3的值，而exp2不会被执行

print(true ? "true" @ "false")

print(false ? "true" @ "false")

--需要注意以下特别写法
--两者输出结果不同
print( 4 ? 1 @ nil ? false @ 3)
print( (4 ? 1 @ nil) ? false @ 3 )
--当不以 () 包含子表达式时
--每个@ 以后的代码将作为exp3进行解析
--即 4 ? 1 @ nil ? false @ 3被解析为 4 ? 1 @ (nil ? false @ 3)
print( 4 ? 1 ? nil @ false @ 3)

--注意多个三目表达式嵌套时，应当使用()把子句包裹起来，避免歧义
--print( exp1 ? exp2 @ exp3 ? exp4 @ exp5)
--print( (exp1 ? exp2 @ exp3) ? exp4 @ exp5)
--print( exp1 ? exp2 @ (exp3 ? exp4 @ exp5))
--print( exp1 ? (exp2 ? exp3 @ exp4) @ exp5)

--具体的三目运算书写参考如下：
import "java.lang.System"
consts = {1, 2, 3, nil, true, false}

--三种不同方式实现的三目运算的运算耗时测试
local time1 = System.currentTimeMillis()
for n = 1,100000 do
    local ret = consts[4]
    --print(1 ? 2 @ 3)
    if consts[1] then
        ret = consts[2]
      else
        ret = consts[3]
    end

    --print(1 ? 2 @ nil)
    if consts[1] then
        ret = consts[2]
      else
        ret = consts[4]
    end

    --print(1 ? nil @ 3)
    if consts[1] then
        ret = consts[4]
      else
        ret = consts[3]
    end

    --print(1 ? false @ nil)
    if consts[1] then
        ret = consts[6]
      else
        ret = consts[4]
    end

    --print(nil ? 2 @ 3)
    if consts[4] then
        ret = consts[2]
      else
        ret = consts[3]
    end

    --print(nil ? 2 @ false)
    if consts[4] then
        ret = consts[2]
      else
        ret = consts[6]
    end

    --print(nil ? false @ 3)
    if consts[4] then
        ret = consts[6]
      else
        ret = consts[3]
    end

    --print(nil ? nil @ false)
    if consts[4] then
        ret = consts[4]
      else
        ret = consts[6]
    end

end
local time2 = System.currentTimeMillis()

print("if exp1 then exp2 else exp3 end \n语句10万次耗时：",time2-time1)


local time1 = System.currentTimeMillis()
for n = 1,100000 do
    local ret = consts[4]
    --print(1 ? 2 @ 3)
    ret = ( consts[1] and { consts[2] } or { consts[3] })[1]

    --print(1 ? 2 @ nil)
    ret = ( consts[1] and { consts[2] } or { consts[4] })[1]

    --print(1 ? nil @ 3)
    ret = ( consts[1] and { consts[4] } or { consts[3] })[1]

    --print(1 ? false @ nil)
    ret = ( consts[1] and { consts[6] } or { consts[4] })[1]

    --print(nil ? 2 @ 3)
    ret = ( consts[4] and { consts[2] } or { consts[3] })[1]

    --print(nil ? 2 @ false)
    ret = ( consts[4] and { consts[2] } or { consts[6] })[1]

    --print(nil ? false @ 3)
    ret = ( consts[4] and { consts[6] } or { consts[3] })[1]

    --print(nil ? nil @ false)
    ret = ( consts[4] and { consts[4] } or { consts[6] })[1]

end
local time2 = System.currentTimeMillis()

print("(exp1 and {exp2} or {exp3})[1] \n语句10万次耗时：",time2-time1)

local time1 = System.currentTimeMillis()
for n = 1,100000 do
    local ret = consts[4]
    ret = consts[1] ? consts[2] @ consts[3]

    ret = consts[1] ? consts[2] @ consts[4]

    ret = consts[1] ? consts[4] @ consts[3]

    ret = consts[1] ? consts[6] @ consts[4]

    ret = consts[4] ? consts[2] @ consts[3]

    ret = consts[4] ? consts[2] @ consts[6]

    ret = consts[4] ? consts[6] @ consts[3]

    ret = consts[4] ? consts[4] @ consts[6]

end
local time2 = System.currentTimeMillis()

print("exp1 ? exp2 @ exp3 \n语句10万次耗时：",time2-time1)
--测试结果为 ? @ 的运算耗时为if then else end语句的1~2倍
--以后再优化执行速度吧

print("\n\n测试三目运算结果\n\n")
print("true ? true @ 3")
print(1 ? 2 @ 3)
print("true ? true @ nil")
print(1 ? 2 @ nil)
print("true ? nil @ 3")
print(1 ? nil @ 3)
print("true ? false @ nil")
print(1 ? false @ nil)

print("nil ? 2 @ 3")
print(nil ? 2 @ 3)
print("nil ? 2 @ false")
print(nil ? 2 @ false)
print("nil ? false @ 3")
print(nil ? false @ 3)
print("nil ? nil @ false")
print(nil ? nil @ false)