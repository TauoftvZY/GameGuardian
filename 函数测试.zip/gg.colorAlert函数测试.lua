--测试

--标题和显示内容均为html文本格式
title = "<font color='#70f3ff'>title</font>"
message = "<font color='#FFFF00'>Test</font>"
gg.colorAlert(title,message,"加入","取消","犹豫")
--五个参数
--标题、文本、积极按钮、消极按钮、中立按钮

--正确用法
gg.colorAlert(title,message,"积极按钮","消极按钮","中立按钮")
gg.colorAlert(nil,message,"加入","取消","犹豫")
gg.colorAlert(title,message)
gg.colorAlert("提示：","你正在测试脚本！")
gg.colorAlert(nil,"Test")

html = gg.makeRequest("https://www.runoob.com/w3cnote/htmlcss-make-a-website.html").content


gg.colorAlert(nil,html)
--初前面多了个自定义标题外，其他与原版无差异

--错误用法
--gg.colorAlert(message,"加入","取消","犹豫")