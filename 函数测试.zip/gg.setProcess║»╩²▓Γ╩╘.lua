print("当前已选择进程：",gg.getTargetInfo().cmdLine,"\n")
print("设置进程：",gg.setProcess("com.android.systemui"),"\n")

--[[--一般而言首次执行设置进程函数后，进程设置成功，但选择应用处的bar文字不会刷新
--可选择执行两次函数来达到刷新效果
function update(name)
 pcall(gg.setProcess,name)
 gg.sleep(200)
 return pcall(gg.setProcess,name)
end
update("com.android.systemui") --设置并刷新进程
]]

print("已更新进程为：",gg.getTargetInfo().cmdLine,"\n")
