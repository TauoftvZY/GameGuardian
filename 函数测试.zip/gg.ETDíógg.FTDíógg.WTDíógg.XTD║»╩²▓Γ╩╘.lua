--各数据转换为Dword---
--数据类型适用于无法直接改的数据类型，间接改有效的情况

--------------------------------------------------
--F转D
function Float_to_Dword(f)
  local a = 23
  local b = 1065353216
  local dw = (b + (math.floor(math.log(f) / math.log(2)) * math.pow(2, a)) + (math.pow(2, a - math.floor(math.log(f) / math.log(2))) * (f - math.pow(2, math.floor(math.log(f) / math.log(2))))))
  if string.find(dw,"E") then
    dw = string.sub(dw,1,1)..string.sub(dw,3,11)
    return table.pack(dw:gsub("E", "0"))[1]
   else
    return dw
  end
end

--例子：
--1304ADFC 1,069,547,520D; 1.5F;   Jh
--1304AE00  318,892,792D; 1.63979376e-27F;  Jh
print("\nFloat_to_Dword转换结果：")
print(Float_to_Dword(1.5)) --1069547520
print(Float_to_Dword(100000000000000000)) --1538368188
print("\ngg.FTD转换结果：")
print(gg.FTD(1.5)) --1069547520
print(gg.FTD(100000000000000000)) --1538368188

--注意：
--传入的数据不能超过Float类型的数据范围
--转换仅限于正整数和正有限小数


--------------------------------------------------
--E转D
function Double_to_Dword(f)
  local a = 20
  local b = 1072693248
  local dw = (b + (math.floor(math.log(f) / math.log(2)) * math.pow(2, a)) + (math.pow(2, a - math.floor(math.log(f) / math.log(2))) * (f - math.pow(2, math.floor(math.log(f) / math.log(2))))))
  if string.find(dw,"E") then
    dw = string.sub(dw,1,1)..string.sub(dw,3,11)
    return table.pack(dw:gsub("E", "0"))[1]
   else
    return dw
  end
end

--例子：
--70276590  0D;  1.0E;  O
--70276594  1,072,693,248D;  5.29980882e-315E;    O
print("\nDouble_to_Dword转换结果：")
print(Double_to_Dword(1)) --1072693248
print("\ngg.ETD转换结果：")
print(gg.ETD(1)) --1072693248
--注意事项与Float_to_Dword相同
--通常为上个地址的Double转为下个地址的Dword
--地址值相差4


--------------------------------------------------
--W转D
--function Word_to_Dword(w,addr)
--  local a = {{address=addr,flags = gg.TYPE_WORD}}
--  local Word= gg.getValues(a)[1].value
--  return w*65536 + Word
--end

--例子：
--702765A0 1,882,090,456D; 27,608W;  O
--702765A2 28,718W; O

--print(Word_to_Dword(28718,0x702765A0)) --1882090456

--通常为下个地址的Word转为上个地址的Dword
--地址值相差2

--当然你也可以这么写
function Word_to_Dword(addr,w)
  local a = {{address=addr + 2,flags = gg.TYPE_WORD}}
  local Word= gg.getValues(a)[1].value
  return Word*65536 + w
end

--例子：
--702765A0 1,882,090,456D; 27,608W;  O
--702765A2 28,718W; O

--27,608W修改为45W
print("\nWord_to_Dword转换结果：")
print(Word_to_Dword(0x702765A0,45)) --1882062893
print("\ngg.WTD转换结果：")
print(gg.WTD(0x702765A0,45)) --1882062893
--------------------------------------------------
--X转D
function Xor_to_Dword(addr,x)
  local a = {{address=addr,flags = gg.TYPE_XOR}}
  local x= gg.getValues(a)[1].value
  return x~addr
end

--例子：
--702765DC 1,881,630,224D; 972X;  O
print("\nXor_to_Dword转换结果：")
print(Xor_to_Dword(0x702765DC,972)) --1881630224
print("\ngg.XTD转换结果：")
print(gg.XTD(0x702765DC,972)) --1881630224