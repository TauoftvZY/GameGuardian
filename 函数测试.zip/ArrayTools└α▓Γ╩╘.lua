--[[
   用于解决在使用 int{1, 2, 3} 或 local b = byte[44] 或 Inteher{1, 2, 3, 4}等形式创建基础数据类型数组时
   无法正常传递给java方法使用的情况
   使用import函数来访问该类
   
   该类中有一维和二维数组创建的方法

   ☆1.1 将一个java封装类型的数组转为基本数据类型一维数组
       或将一个lua的表转为目标类型的一维数组
       参数一，传入表长度，参数二传入lua表或者封装类型数组
       ArrayTools.floatOf(int length, Float[] f) --Float为基本数据类型float的封装类
       ArrayTools.floatOf(int length, LuaTable t) --LuaTable的表示可以直接传一个lua层的表
       ArrayTools.doubleOf(int length, Double[] f) --Double为基本数据类型double的封装类, 这里传的是Double的一维数组
       ArrayTools.doubleOf(int length, LuaTable t)
       ArrayTools.byteOf(int length, Byte[] f) --Byte为byte基本数据类型的封装类
       ArrayTools.byteOf(int length, LuaTable t)
       ArrayTools.charOf(int length, Character[] f) --Character为基本数据类型char的封装类
       ArrayTools.charOf(int length, LuaTable t)
       ArrayTools.intOf(int length, Integer[] f) --Integer为基本数据类型int的封装类
       ArrayTools.intOf(int length, LuaTable t)
       ArrayTools.longOf(int length, Long[] f) --Long为基本数据类型long的封装类
       ArrayTools.longOf(int length, LuaTable t)
       ArrayTools.booleanOf(int length, Boolean[] f) --Boolean为基本数据类型boolean的封装类
       ArrayTools.booleanOf(int length, LuaTable t)
       ArrayTools.stringOf(int length, LuaTable t)
       ArrayTools.classOf(int length, LuaTable t)
       ArrayTools.objectOf(int length, LuaTable t)
       ArrayTools.shortOf(int length, Short[] f) --Short为基本数据类型short的封装类
       ArrayTools.shortOf(int length, LuaTable t)
       
   ☆1.2 将一个java封装类型的数组转为基本数据类型二维数组
       或将一个lua的表转为目标类型的二维数组
       参数一，传入二维数组的长，参数二传入二维数组的宽，参数三传入lua表或者封装类型数组
       ArrayTools.floatOf(int length, int childlen, Float[][] f)
       ArrayTools.floatOf(int length, int childlen, LuaTable t)
       ArrayTools.doubleOf(int length, int childlen, Double[][] f)
       ArrayTools.doubleOf(int length, int childlen, LuaTable t)
       ArrayTools.byteOf(int length, int childlen, Byte[][] f)
       ArrayTools.byteOf(int length, int childlen, LuaTable t)
       ArrayTools.charOf(int length, int childlen, Character[][] f)
       ArrayTools.charOf(int length, int childlen, LuaTable t)
       ArrayTools.intOf(int length, int childlen, Integer[][] f)
       ArrayTools.intOf(int length, int childlen, LuaTable t)
       ArrayTools.longOf(int length, int childlen, Long[][] f)
       ArrayTools.longOf(int length, int childlen, LuaTable t)
       ArrayTools.booleanOf(int length, int childlen, Boolean[][] f)
       ArrayTools.booleanOf(int length, int childlen, LuaTable t)
       ArrayTools.stringOf(int length, int childlen, LuaTable t)
       ArrayTools.classOf(int length, int childlen, LuaTable t)
       ArrayTools.objectOf(int length, int childlen, LuaTable t)
       ArrayTools.shortOf(int length, int childlen, Short[][] f)
       ArrayTools.shortOf(int length, int childlen, LuaTable t)
]]

--以下是部分使用方法，其他的同理
import "com.util.ArrayTools"
local k = {1.0, 8.8, 55}
k = ArrayTools.doubleOf(3, k)
print("double[]：",k)
print("double[0]：",k[1])

local b = {68, 77}
b = ArrayTools.byteOf(2, b)
print("byte[]：",b)
print("byte[0]：",b[1])
import "java.lang.String"
print("byte[]转String：",String(b))

local cc = {
  {1,2,3},
  {4,5,6},
  {7,8,9},
}
cc = ArrayTools.intOf(3,3,cc)
print("int[][]：",cc)
print("int[1][]：",cc[2])
print("int[1][2]：",cc[2][3])