--将函数导入，方便后面编写
print("打印luajava库拥有函数：\n",luajava)
local class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable
local methods = luajava.methods
--luajava.astable的测试
print("\n\n\nluajava.astable的测试：\n")
--这里是创建File对象
print("\n   创建文件夹及文件：")
local File = new(class("java.io.File"),"/sdcard/测试")
print("  ", File:mkdirs())
local File = new(class("java.io.File"),"/sdcard/测试/HelloLuaJ.txt")
print("  ", File:createNewFile())
--对File对象进行文件遍历
print("\n\n   对File对象进行文件遍历：")
local File = new(class("java.io.File"),"/sdcard/测试")
local list = File:listFiles()
print("   不使用luajava.astable时无法查看详情：\n",list)
print("\n   使用luajava.astable转为table数据：\n",astable(list))
--luajava.methods的测试
print("\n\n\nluajava.methods的测试：\n\n\n   当前测试基础包：")
print(methods("java.io.File"))
print("\n\n   当前测试GG内部包：")
print(methods("luaj.LuaTable"))